"""
Level 3: Graduation Audit & Deficiency Reporter
Complete graduation eligibility check against program requirements
"""

from typing import Dict, List, Set, Optional
from dataclasses import dataclass, field
from models.transcript import Transcript
from models.program import ProgramRequirements
from calculators.credit_calculator import CreditCalculator, CreditReport
from calculators.gpa_calculator import GPACalculator, GPAReport


@dataclass
class DeficiencyReport:
    """Report of missing requirements"""
    missing_mandatory: List[str] = field(default_factory=list)
    missing_core: List[str] = field(default_factory=list)
    missing_major_core: List[str] = field(default_factory=list)
    unsatisfied_groups: Dict[str, dict] = field(default_factory=dict)
    credit_deficit: float = 0.0
    cgpa_deficit: float = 0.0


@dataclass
class AuditReport:
    """Complete graduation audit report"""
    # Basic info
    student_id: Optional[str]
    student_name: Optional[str]
    program_name: str
    
    # Graduation eligibility
    can_graduate: bool
    deficiencies: DeficiencyReport
    
    # Sub-reports
    credit_report: CreditReport
    gpa_report: GPAReport
    
    # Course tracking
    completed_courses: Set[str]
    retaken_courses: Dict[str, List[dict]]
    
    def __str__(self) -> str:
        status = "✓ ELIGIBLE TO GRADUATE" if self.can_graduate else "✗ NOT ELIGIBLE TO GRADUATE"
        status_line = f"\n{status}\n"
        
        student_info = ""
        if self.student_id or self.student_name:
            student_info = f"\nStudent: {self.student_name or 'N/A'} ({self.student_id or 'N/A'})\n"
        
        return f"""
{'=' * 70}
GRADUATION AUDIT REPORT
{'=' * 70}{student_info}
Program: {self.program_name}
{status_line}
{self._format_summary()}

{self._format_deficiencies()}

{self._format_retakes()}
{'=' * 70}
"""
    
    def _format_summary(self) -> str:
        """Format summary section"""
        lines = ["SUMMARY"]
        lines.append("-" * 70)
        
        # Credits
        credit_check = "✓" if self.deficiencies.credit_deficit == 0 else "✗"
        lines.append(f"{credit_check} Credits: {self.credit_report.total_earned_credits:.1f} earned")
        if self.deficiencies.credit_deficit > 0:
            lines.append(f"   Need {self.deficiencies.credit_deficit:.1f} more credits")
        
        # CGPA
        cgpa_check = "✓" if self.deficiencies.cgpa_deficit == 0 else "✗"
        lines.append(f"{cgpa_check} CGPA: {self.gpa_report.cgpa:.2f}")
        if self.deficiencies.cgpa_deficit > 0:
            lines.append(f"   Need {self.deficiencies.cgpa_deficit:.2f} higher CGPA")
        lines.append(f"   Standing: {self.gpa_report.class_standing}")
        
        # Courses
        total_missing = (len(self.deficiencies.missing_mandatory) +
                        len(self.deficiencies.missing_core) +
                        len(self.deficiencies.missing_major_core))
        course_check = "✓" if total_missing == 0 else "✗"
        lines.append(f"{course_check} Required Courses: {len(self.completed_courses)} completed")
        if total_missing > 0:
            lines.append(f"   Missing {total_missing} required courses")
        
        # Groups
        unsat_count = sum(1 for g in self.deficiencies.unsatisfied_groups.values()
                         if not g['satisfied'])
        group_check = "✓" if unsat_count == 0 else "✗"
        lines.append(f"{group_check} Course Groups: {len(self.deficiencies.unsatisfied_groups) - unsat_count} satisfied")
        if unsat_count > 0:
            lines.append(f"   {unsat_count} groups incomplete")
        
        return "\n".join(lines)
    
    def _format_deficiencies(self) -> str:
        """Format deficiencies section"""
        if self.can_graduate:
            return "No deficiencies - all requirements met!"
        
        lines = ["\nDEFICIENCIES"]
        lines.append("-" * 70)
        
        # Missing courses
        if self.deficiencies.missing_mandatory:
            lines.append("\nMissing Mandatory GED Courses:")
            for course in sorted(self.deficiencies.missing_mandatory):
                lines.append(f"  • {course}")
        
        if self.deficiencies.missing_core:
            lines.append("\nMissing Core Courses:")
            for course in sorted(self.deficiencies.missing_core):
                lines.append(f"  • {course}")
        
        if self.deficiencies.missing_major_core:
            lines.append("\nMissing Major Core Courses:")
            for course in sorted(self.deficiencies.missing_major_core):
                lines.append(f"  • {course}")
        
        # Unsatisfied groups
        unsat_groups = {name: info for name, info in self.deficiencies.unsatisfied_groups.items()
                       if not info['satisfied']}
        if unsat_groups:
            lines.append("\nIncomplete Course Groups:")
            for name, info in unsat_groups.items():
                lines.append(f"  • {name}: {info['completed']}/{info['required']} completed")
                lines.append(f"    Need {info['missing']} more course(s)")
        
        return "\n".join(lines)
    
    def _format_retakes(self) -> str:
        """Format retaken courses section"""
        if not self.retaken_courses:
            return ""
        
        lines = ["\nRETAKEN COURSES"]
        lines.append("-" * 70)
        
        for course_code in sorted(self.retaken_courses.keys()):
            attempts = self.retaken_courses[course_code]
            lines.append(f"\n{course_code}:")
            for i, attempt in enumerate(attempts, 1):
                symbol = "→" if i < len(attempts) else "✓"
                lines.append(f"  {symbol} {attempt['grade']} ({attempt['semester']})")
        
        return "\n".join(lines)


class AuditCalculator:
    """
    Level 3: Graduation Audit Engine
    
    Performs complete graduation check:
    1. Verify credit requirements
    2. Verify CGPA requirements
    3. Check all mandatory courses
    4. Check course group requirements
    5. Handle retakes properly
    6. Generate deficiency report
    """
    
    @staticmethod
    def perform_audit(transcript: Transcript,
                     program: ProgramRequirements,
                     waived_courses: Optional[Set[str]] = None) -> AuditReport:
        """
        Perform complete graduation audit.
        
        Args:
            transcript: Student transcript
            program: Program requirements
            waived_courses: Set of waived courses
            
        Returns:
            Complete audit report
        """
        if waived_courses is None:
            waived_courses = set()
        
        # Normalize waived courses
        waived_courses = {c.upper().strip() for c in waived_courses}
        
        # Run sub-calculations
        credit_report = CreditCalculator.calculate_credits(transcript)
        gpa_report = GPACalculator.calculate_cgpa(transcript, waived_courses)
        
        # Get completed courses (best attempts only, excluding waived)
        completed_courses = set()
        for course_code in transcript.get_unique_courses():
            if course_code in waived_courses:
                continue
            best = transcript.get_best_attempt(course_code)
            # Only count if passed
            if best and best.is_passing:
                completed_courses.add(course_code)
        
        # Check requirements
        deficiencies = DeficiencyReport()
        
        # 1. Check credit requirement
        if credit_report.total_earned_credits < program.total_credits_required:
            deficiencies.credit_deficit = (
                program.total_credits_required - credit_report.total_earned_credits
            )
        
        # 2. Check CGPA requirement
        if gpa_report.cgpa < program.minimum_cgpa:
            deficiencies.cgpa_deficit = program.minimum_cgpa - gpa_report.cgpa
        
        # 3. Check mandatory courses (excluding waived)
        missing = program.check_mandatory_completion(completed_courses)
        deficiencies.missing_mandatory = [
            c for c in missing['mandatory'] if c not in waived_courses
        ]
        deficiencies.missing_core = [
            c for c in missing['core'] if c not in waived_courses
        ]
        deficiencies.missing_major_core = [
            c for c in missing['major_core'] if c not in waived_courses
        ]
        
        # 4. Check course groups
        deficiencies.unsatisfied_groups = program.check_course_groups(completed_courses)
        
        # Determine if can graduate
        can_graduate = (
            deficiencies.credit_deficit == 0 and
            deficiencies.cgpa_deficit == 0 and
            len(deficiencies.missing_mandatory) == 0 and
            len(deficiencies.missing_core) == 0 and
            len(deficiencies.missing_major_core) == 0 and
            all(g['satisfied'] for g in deficiencies.unsatisfied_groups.values())
        )
        
        # Track retakes
        retaken = {}
        for course_code, attempts in transcript.get_retaken_courses().items():
            retaken[course_code] = [
                {
                    'grade': att.grade,
                    'semester': att.semester,
                    'credits': att.credits
                }
                for att in sorted(attempts, key=lambda x: x.semester)
            ]
        
        return AuditReport(
            student_id=transcript.student_id,
            student_name=transcript.student_name,
            program_name=program.program_name,
            can_graduate=can_graduate,
            deficiencies=deficiencies,
            credit_report=credit_report,
            gpa_report=gpa_report,
            completed_courses=completed_courses,
            retaken_courses=retaken
        )
    
    @staticmethod
    def generate_detailed_report(audit: AuditReport) -> str:
        """Generate comprehensive detailed report"""
        lines = [str(audit)]
        
        # Add credit breakdown
        from calculators.credit_calculator import CreditCalculator
        lines.append("\n" + CreditCalculator.get_detailed_breakdown(audit.credit_report))
        
        # Add semester GPA breakdown
        from calculators.gpa_calculator import GPACalculator
        lines.append("\n" + GPACalculator.get_semester_breakdown(audit.gpa_report))
        
        return "\n".join(lines)


if __name__ == "__main__":
    from parsers.csv_parser import TranscriptParser
    from models.program import ProgramFactory
    import tempfile
    import os
    
    print("LEVEL 3: Audit Calculator Test")
    print("=" * 70)
    
    # Create test transcript
    with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
        test_file = f.name
    
    try:
        TranscriptParser.create_sample_csv(test_file, include_edge_cases=True)
        transcript = TranscriptParser.parse_csv(
            test_file,
            student_id="2014567890",
            student_name="Test Student",
            program="BBA"
        )
        
        # Create BBA program
        program = ProgramFactory.create_bba_program()
        
        # Perform audit
        audit = AuditCalculator.perform_audit(transcript, program)
        
        # Print reports
        print(audit)
        
        print("\n\nDETAILED REPORT:")
        print(AuditCalculator.generate_detailed_report(audit))
        
    finally:
        if os.path.exists(test_file):
            os.unlink(test_file)
